const API_HOST = "cco-agent.bantusaku.id";
const AUTH_NAMES = new Set([
  "authorization","x-authorization","x-access-token","x-auth-token",
  "access-token","x-token","token"
]);

chrome.webRequest.onBeforeSendHeaders.addListener(
  async (details) => {
    if (!details.url.startsWith("https://" + API_HOST + "/api/")) return;
    const found = {};
    for (const h of (details.requestHeaders || [])) {
      const n = (h.name || "").toLowerCase();
      if (AUTH_NAMES.has(n) && h.value) found[h.name] = h.value;
    }
    if (Object.keys(found).length) {
      // Keep auth scoped to the tab that owns the login/session.
      // This prevents another CCO tab from overwriting the credentials
      // used by the tool while the user switches tabs.
      const key = `capturedAuth_${details.tabId}`;
      await chrome.storage.session.set({
        [key]: {
          auth: found,
          capturedAt: Date.now(),
          capturedUrl: details.url,
          tabId: details.tabId
        }
      });
    }
  },
  { urls: ["https://" + API_HOST + "/api/*"] },
  ["requestHeaders", "extraHeaders"]
);

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "capturePageAuth") {
    const tabId = sender?.tab?.id;
    const auth = msg?.headers || {};
    if (Number.isInteger(tabId) && Object.keys(auth).length) {
      const key = `capturedAuth_${tabId}`;
      chrome.storage.session.set({
        [key]: {
          auth,
          capturedAt: Date.now(),
          capturedUrl: String(msg.url || ""),
          tabId
        }
      }).then(() => sendResponse({ok:true}));
      return true;
    }
    sendResponse({ok:false});
    return false;
  }
  if (msg?.type === "getCapturedAuth") {
    const tabId = Number(msg.tabId);
    const key = Number.isInteger(tabId) ? `capturedAuth_${tabId}` : "";
    if (!key) {
      sendResponse({auth:{},capturedAt:0,capturedUrl:"",tabId:0});
      return false;
    }
    chrome.storage.session.get(key).then(x => {
      const v = x[key] || {};
      sendResponse({
        auth: v.auth || {},
        capturedAt: v.capturedAt || 0,
        capturedUrl: v.capturedUrl || "",
        tabId: v.tabId || tabId
      });
    });
    return true;
  }
  if (msg?.type === "clearCapturedAuth") {
    const tabId = Number(msg.tabId);
    const key = Number.isInteger(tabId) ? `capturedAuth_${tabId}` : "";
    (key ? chrome.storage.session.remove(key) : Promise.resolve()).then(() => sendResponse({ok:true}));
    return true;
  }
});


chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.session.remove(`capturedAuth_${tabId}`).catch(() => {});
});

// ===== SIDE PANEL TOOLS =====
// Tools stay attached to the current Chrome tab instead of opening a new tab/window.
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "closeToolsWindow") {
    const tabId = sender?.tab?.id;
    if (tabId != null && chrome.sidePanel?.close) {
      chrome.sidePanel.close({ tabId }).then(
        () => sendResponse({ok: true}),
        () => sendResponse({ok: false})
      );
      return true;
    }
    sendResponse({ok: false});
  }
});

// ===== LICENSE ENFORCEMENT (SERVER AUTHORITY) =====
const LICENSE_SERVER_URL_BG = "https://extension-tools.div2.workers.dev";
const LICENSE_ALARM = "license-enforcement";
async function bgReadLicense(){
  try { const s=await chrome.storage.local.get(["license","device_binding_id","hardware_id"]); return {lic:s?.license||{},hw:String(s?.device_binding_id||s?.hardware_id||"").toUpperCase()}; } catch(_) { return {lic:{},hw:""}; }
}
async function bgValidateLicense(){
  const {lic,hw}=await bgReadLicense();
  if(!lic?.license_key || !hw) return {ok:false,reason:"NO_LICENSE"};
  const ctl=new AbortController(); const timer=setTimeout(()=>ctl.abort(),10000);
  try {
    const r=await fetch(LICENSE_SERVER_URL_BG+"/validate",{method:"POST",headers:{"content-type":"application/json","cache-control":"no-cache"},cache:"no-store",body:JSON.stringify({license_key:String(lic.license_key),hardware_id:hw,app_version:chrome.runtime.getManifest().version}),signal:ctl.signal});
    let d={}; try{d=await r.json()}catch(_){}
    if(!r.ok || d?.valid===false || d?.active===false || !d?.expires_at) return {ok:false,reason:String(d?.error||d?.message||("HTTP "+r.status))};
    const end=Date.parse(String(d.expires_at));
    if(!Number.isFinite(end) || end<=Date.now()) return {ok:false,reason:"LICENSE_EXPIRED"};
    await chrome.storage.local.set({license:{...lic,expires_at:d.expires_at,validated_at:Date.now()}});
    return {ok:true,expires_at:d.expires_at};
  } catch(e) { return {ok:false,reason:String(e?.message||e||"LICENSE_SERVER_ERROR")}; }
  finally { clearTimeout(timer); }
}
async function bgStopCcoTabs(){
  try {
    const tabs=await chrome.tabs.query({url:["https://cco-agent.bantusaku.id/*"]});
    await Promise.all(tabs.map(t=>chrome.tabs.sendMessage(t.id,{type:"LICENSE_REVOKED",reason:"License tidak aktif atau sudah dicabut oleh server."}).catch(()=>{})));
  } catch(_) {}
}
async function enforceLicense(){
  const result=await bgValidateLicense();
  if(!result.ok){
    const {lic}=await bgReadLicense();
    if(lic?.license_key) {
      try { await chrome.storage.local.set({license_server_blocked:true,license_block_reason:result.reason,license_blocked_at:Date.now()}); } catch(_) {}
      await bgStopCcoTabs();
    }
  } else {
    try { await chrome.storage.local.set({license_server_blocked:false,license_block_reason:"",license_last_ok_at:Date.now()}); } catch(_) {}
  }
  return result;
}
chrome.runtime.onInstalled.addListener(()=>{ try{chrome.alarms.create(LICENSE_ALARM,{periodInMinutes:1});}catch(_){}; enforceLicense(); });
chrome.runtime.onStartup.addListener(()=>{ try{chrome.alarms.create(LICENSE_ALARM,{periodInMinutes:1});}catch(_){}; enforceLicense(); });
chrome.alarms.onAlarm.addListener(a=>{ if(a?.name===LICENSE_ALARM) enforceLicense(); });
