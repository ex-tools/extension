const PRODUCTS = new Set(["Scraper Tools", "BantuSaku Scraper Pro"]);



const $=id=>document.getElementById(id);

let apiModalBusy=false;
let runUiActive=false;

function showApiModal(title="API belum terdeteksi", text="Session API pada tab Chrome aktif belum terdeteksi. Silakan refresh halaman lalu coba lagi.", hint="Pastikan Anda sudah login di cco-agent.bantusaku.id."){
  const modal=$("apiModal"); if(!modal)return;
  $("apiModalTitle").textContent=title;
  $("apiModalText").textContent=text;
  $("apiModalHint").textContent=hint;
  modal.hidden=false;
}
function hideApiModal(){ const modal=$("apiModal"); if(modal) modal.hidden=true; }

async function findSessionTab(preferredTabId=null){
  try{
    const r=await new Promise(resolve=>chrome.runtime.sendMessage({type:"GET_CCO_TABS",preferredTabId},resolve));
    const tabs=r?.tabs||[];
    if(!tabs.length) return null;

    // Do not depend on the currently focused Chrome window. Iterate through
    // every open CCO tab, including tabs in other Chrome windows, and prefer
    // one where the content script is alive and auth is available. This keeps
    // detection stable when the user switches windows or another application.
    const ordered=[...tabs].sort((a,b)=>{
      const score=t=>Number(t.id===preferredTabId)*4+Number(t.hasAuth)*2;
      return score(b)-score(a);
    });
    let contentFallback=null;
    for(const tab of ordered){
      if(!tab?.id) continue;
      let content=false;
      try{ const pong=await chrome.tabs.sendMessage(tab.id,{type:"PING"}); content=!!pong?.ok; }catch(_){}
      if(!content) continue;
      if(!contentFallback) contentFallback=tab;
      let auth=tab.hasAuth;
      try{
        let a=await new Promise(resolve=>chrome.runtime.sendMessage({type:"GET_AUTH_HEADERS",tabId:tab.id},resolve));
        auth=!!(a?.headers&&Object.keys(a.headers).length);
        if(!auth){
          const discovered=await new Promise(resolve=>chrome.tabs.sendMessage(tab.id,{type:"DISCOVER_AUTH"},resolve));
          if(discovered?.headers&&Object.keys(discovered.headers).length){
            await new Promise(resolve=>chrome.runtime.sendMessage({type:"SET_AUTH_HEADERS",tabId:tab.id,headers:discovered.headers},resolve));
            auth=true;
          }
        }
      }catch(_){}
      if(auth) return {...tab,hasAuth:true};
    }
    return contentFallback || ordered[0] || null;
  }catch(_){ return null; }
}

async function inspectSession(){
  const tab=await findSessionTab();
  const result={tab,site:false,content:false,api:false};
  if(!tab?.id)return result;
  result.site=true;
  try{ const pong=await chrome.tabs.sendMessage(tab.id,{type:"PING"}); result.content=!!pong?.ok; }catch(_){ result.content=false; }
  if(!result.content) return result;
  try{
    let r=await new Promise(resolve=>chrome.runtime.sendMessage({type:"GET_AUTH_HEADERS",tabId:tab.id},resolve));
    result.api=!!(r?.ok&&r.headers&&Object.keys(r.headers).length);
    if(!result.api){
      const discovered=await new Promise(resolve=>chrome.tabs.sendMessage(tab.id,{type:"DISCOVER_AUTH"},resolve));
      if(discovered?.headers&&Object.keys(discovered.headers).length){
        await new Promise(resolve=>chrome.runtime.sendMessage({type:"SET_AUTH_HEADERS",tabId:tab.id,headers:discovered.headers},resolve));
        result.api=true;
      }
    }
  }catch(_){ result.api=false; }
  return result;
}

async function inspectActiveTab(){
  return inspectSession();
}

async function checkApiConnection(showPopup=false){
  if(apiModalBusy)return false;
  const state=await inspectActiveTab();
  const ready=state.site && state.content && state.api;
  const notice=$("siteNotice");
  if(ready){
    if(notice){ notice.classList.remove("session-warning"); notice.classList.add("session-ok"); notice.textContent="API/session terdeteksi. Siap scrape."; }
    return true;
  }
  if(notice){
    notice.classList.remove("session-ok"); notice.classList.add("session-warning");
    notice.textContent=state.site ? "API/session belum terdeteksi. Refresh halaman Chrome lalu coba lagi." : "Buka dan login ke cco-agent.bantusaku.id pada salah satu tab Chrome. Tab aktif tidak harus menjadi sumber session.";
  }
  if(showPopup){
    if(!state.site) showApiModal("Tab belum siap","Buka dan login ke cco-agent.bantusaku.id pada salah satu tab Chrome sebelum menjalankan scraper.","Setelah halaman terbuka dan login, klik Coba Lagi.");
    else if(!state.content) showApiModal("Session belum siap","Extension belum terhubung ke halaman aktif. Refresh halaman agar extension terpasang kembali.","Klik REFRESH HALAMAN, tunggu halaman selesai dimuat, lalu coba lagi.");
    else if(!state.api) showApiModal("API belum terdeteksi","Extension belum menangkap session/API request dari halaman aktif. Refresh halaman untuk memuat ulang session.","Pastikan Anda sudah login dan tunggu halaman selesai dimuat sebelum scrape.");
  }
  return false;
}

async function refreshActivePage(){
  const tab=await findSessionTab(); if(!tab?.id)return;
  apiModalBusy=true;
  try{
    await chrome.tabs.reload(tab.id); hideApiModal();
    $("status").textContent="Halaman sumber session sedang di-refresh. Tunggu sebentar...";
    setTimeout(async()=>{ apiModalBusy=false; await checkApiConnection(false); },2500);
  }catch(_){
    apiModalBusy=false;
    showApiModal("Refresh gagal","Halaman sumber session tidak dapat di-refresh otomatis. Silakan refresh tab CCO secara manual.","Setelah selesai, klik Coba Lagi.");
  }
}

function showActivationAlert(title,text,type="error"){
  const box=$("activationAlert");
  if(!box)return;
  $("activationAlertTitle").textContent=title;
  $("activationAlertText").textContent=text;
  box.className=`activation-alert ${type}`;
  box.hidden=false;
}
function hideActivationAlert(){
  const box=$("activationAlert");
  if(box)box.hidden=true;
}
function explainActivationError(raw){
  const s=String(raw||"").toLowerCase();
  if(!s)return["Aktivasi gagal","Server tidak memberikan pesan error. Coba lagi."];
  if(s.includes("not found")||s.includes("invalid")||s.includes("license not found")||s.includes("unknown license"))
    return["License tidak ditemukan","Periksa kembali License Key yang Anda masukkan."];
  if(s.includes("expired")||s.includes("expire"))
    return["License sudah expired","License ini sudah melewati masa aktif. Gunakan license yang masih aktif."];
  if(s.includes("revoked")||s.includes("disabled")||s.includes("suspended"))
    return["License dinonaktifkan","License ini sudah di-revoke atau dinonaktifkan oleh server."];
  if(s.includes("device")&&(s.includes("mismatch")||s.includes("bound")||s.includes("different")||s.includes("limit")))
    return["Device tidak cocok","License sudah terikat ke device lain atau batas device telah tercapai."];
  if(s.includes("network")||s.includes("fetch")||s.includes("failed to fetch")||s.includes("offline")||s.includes("timeout"))
    return["Server tidak dapat dihubungi","Periksa koneksi internet dan pastikan License Server sedang online."];
  if(s.includes("401")||s.includes("403")||s.includes("unauthorized")||s.includes("forbidden"))
    return["Akses ditolak","License Server menolak permintaan aktivasi. Periksa konfigurasi server."];
  if(s.includes("500")||s.includes("502")||s.includes("503"))
    return["Server sedang bermasalah","Coba lagi beberapa saat lagi. Jika berulang, periksa License Server."];
  return["Aktivasi gagal",String(raw).replace(/^error:\s*/i,"").slice(0,180)];
}


function showMenu(name){
  const licensed = name === "scrape";
  $("licenseView").hidden = licensed;
  $("scrapeView").hidden = !licensed;
  $("menuLicense").classList.toggle("active", !licensed);
  $("menuScrape").classList.toggle("active", licensed);
}

function lockScrapeMenu(){
  $("menuScrape").disabled = true;
  $("startPayment")?.setAttribute("disabled", "disabled");
  showMenu("license");
}

function unlockScrapeMenu(){
  $("menuScrape").disabled = false;
  $("startPayment")?.removeAttribute("disabled");
}

let hardwareId="";
let lastLicenseValidationAt=0;
let lastLicenseValidationOk=false;

// Extension-only device binding. No Windows agent/service is required.
// A random device ID is generated once and kept in chrome.storage.local.
// This is a browser-profile binding, not a true Windows hardware ID.
async function getHardwareId(){
  const key="device_binding_id";
  const saved=await chrome.storage.local.get([key]);
  if(saved[key]) return String(saved[key]).toUpperCase();
  const raw=crypto.randomUUID().replaceAll("-","").toUpperCase();
  const id="NEWSCRPR-"+raw;
  await chrome.storage.local.set({[key]:id});
  return id;
}
async function getLicense(){
  const s=await chrome.storage.local.get(["license"]);
  return s.license||{};
}
async function serverStatus(key,hw){
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),10000);
  try{
    const r=await fetch(LICENSE_SERVER_URL+"/validate",{
      method:"POST",headers:{"content-type":"application/json"},
      body:JSON.stringify({license_key:key,hardware_id:hw,app_version:chrome.runtime.getManifest().version,product:"Scraper Tools"}),
      cache:"no-store",signal:controller.signal
    });
    let d={};try{d=await r.json()}catch(_){d={error:"Respons server tidak valid"}}
    if(!r.ok) throw new Error(d.error||d.message||`Server HTTP ${r.status}`);
    if(d.valid===false || d.active===false) throw new Error(d.error||d.message||"LICENSE_INVALID");
    if(!d.expires_at) throw new Error("LICENSE_RESPONSE_MISSING_EXPIRY");
    if(!d.expires_at) throw new Error("LICENSE_RESPONSE_MISSING_EXPIRY");
    return d;
  }catch(e){
    if(e?.name==="AbortError") throw new Error("LICENSE_SERVER_TIMEOUT");
    throw e;
  }finally{clearTimeout(timer);}
}
function parseExpiry(value){
  if(!value) return null;
  const s=String(value);
  const d=new Date(s);
  if(Number.isNaN(d.getTime())) return null;
  // Server returns ISO timestamps; date-only values are treated as end-of-day local time.
  if(/^\d{4}-\d{2}-\d{2}$/.test(s)){
    const [y,m,day]=s.split("-").map(Number);
    return new Date(y,m-1,day,23,59,59,999);
  }
  return d;
}
function formatExpiry(value){
  const d=parseExpiry(value);
  if(!d) return value||"-";
  return d.toLocaleString("id-ID",{dateStyle:"medium",timeStyle:"short"});
}
const LICENSE_CACHE_MS=10*60*1000;

async function licenseInfo(force=false){
  const lic=await getLicense();
  if(!lic.license_key) return {active:false,status:"BELUM AKTIF",expires:"-",expiresAt:null,days:null,key:"-",hw:hardwareId};
  // SECURITY: never grant access from local expiry/cache. The license server
  // must approve the current key + device on every validation.
  try{
    const d=await serverStatus(lic.license_key,hardwareId);
    const end=parseExpiry(d.expires_at), now=new Date();
    if(!end || end.getTime()<=Date.now()) throw new Error("LICENSE_EXPIRED");
    await chrome.storage.local.set({license:{...lic,expires_at:d.expires_at,validated_at:Date.now()}});
    const days=Math.max(0,Math.ceil((end-now)/86400000));
    lastLicenseValidationAt=Date.now(); lastLicenseValidationOk=true;
    return {active:true,status:"AKTIF",expires:formatExpiry(d.expires_at),expiresAt:end.toISOString(),days,key:lic.license_key,hw:hardwareId};
  }catch(e){
    lastLicenseValidationOk=false;
    const msg=String(e.message||e), low=msg.toLowerCase();
    if(low.includes("expired")) return {active:false,status:"EXPIRED",expires:formatExpiry(lic.expires_at),expiresAt:null,days:null,key:lic.license_key,hw:hardwareId};
    if(msg.includes("LICENSE_ALREADY_BOUND_TO_ANOTHER_PC") || msg.includes("HARDWARE_MISMATCH")) return {active:false,status:"DEVICE TIDAK COCOK",expires:formatExpiry(lic.expires_at),expiresAt:null,days:null,key:lic.license_key,hw:hardwareId};
    if(msg.includes("REVOKED")||low.includes("revoke")||low.includes("disabled")||low.includes("suspended")||low.includes("license_invalid")) return {active:false,status:"REVOKED",expires:formatExpiry(lic.expires_at),expiresAt:null,days:null,key:lic.license_key,hw:hardwareId};
    return {active:false,status:"SERVER TIDAK TERHUBUNG",expires:formatExpiry(lic.expires_at),expiresAt:null,days:null,key:lic.license_key,hw:hardwareId};
  }
}
let headerLicenseExpiryAt=null;
function updateHeaderCountdown(){
  const el=$("headerLicenseDays"), header=$("licenseHeader");
  if(!el || !header) return;
  if(!headerLicenseExpiryAt){
    if(el.textContent==="") el.textContent="—";
    return;
  }
  const diff=new Date(headerLicenseExpiryAt).getTime()-Date.now();
  if(diff<=0){
    el.textContent="0 hari";
    header.classList.remove("expiring"); header.classList.add("expired");
    $("headerLicenseStatus").textContent="EXPIRED";
    $("headerLicenseExpiry").textContent="Masa aktif berakhir";
    return;
  }
  const totalMinutes=Math.floor(diff/60000);
  const days=Math.floor(totalMinutes/1440);
  const hours=Math.floor((totalMinutes%1440)/60);
  const mins=totalMinutes%60;
  el.textContent=days>0 ? `${days}h ${hours}j` : `${hours}j ${mins}m`;
  header.classList.toggle("expiring", days < 7);
}
setInterval(updateHeaderCountdown, 30000);

async function refreshLicense(force=false){
  const i=await licenseInfo(force);
  $("licStatus").textContent=i.status;
  $("licExpiry").textContent=i.expires;
  $("licDays").textContent=i.days==null?"-":`${i.days} hari`;
  $("licenseBadge").textContent=i.status;
  $("licenseBadge").className="badge "+(i.active?"ok":"off");
  $("start").disabled=!i.active;
  $("startPayment").disabled=!i.active;
  

  // Header: always show the current license state and remaining active period.
  const header=$("licenseHeader");
  const headerStatus=$("headerLicenseStatus");
  const headerDays=$("headerLicenseDays");
  headerLicenseExpiryAt=i.expiresAt || null;
  const headerExpiry=$("headerLicenseExpiry");
  if(header){
    header.classList.remove("expiring","expired");
    headerStatus.textContent=i.status;
    if(i.active){
      const days=Number(i.days);
      headerDays.textContent=Number.isFinite(days) ? `${days} hari` : "—";
      headerExpiry.textContent=i.expires && i.expires!=="-" ? `s.d. ${i.expires}` : "—";
      if(Number.isFinite(days) && days <= 7) header.classList.add("expiring");
    }else{
      headerDays.textContent=i.status==="EXPIRED" ? "0 hari" : "—";
      headerExpiry.textContent=i.expires && i.expires!=="-" ? `s.d. ${i.expires}` : "—";
      if(i.status==="EXPIRED") header.classList.add("expired");
    }
  }
  updateHeaderCountdown();

  if(i.active){
    unlockScrapeMenu();
    showMenu("scrape");
  }else{
    lockScrapeMenu();
  }
  return i.active;
}
async function activate(){
  hideActivationAlert();
  const key=$("licenseKey").value.trim().toUpperCase();
  if(!key){
    showActivationAlert("License Key kosong","Masukkan License Key terlebih dahulu.");
    return;
  }
  if(key.length<8){
    showActivationAlert("License Key tidak valid","Format License Key terlalu pendek. Periksa kembali key Anda.");
    return;
  }

  const btn=$("activate");
  btn.disabled=true;
  btn.classList.add("loading");
  btn.innerHTML="<span>⏳</span> MEMVERIFIKASI...";
  $("licenseMsg").textContent="Menghubungi License Server...";

  try{
    const r=await fetch(LICENSE_SERVER_URL+"/activate",{
      method:"POST",
      headers:{"content-type":"application/json"},
      body:JSON.stringify({
        license_key:key,
        hardware_id:hardwareId,
        app_version:chrome.runtime.getManifest().version
      })
    });

    let d={};
    try{d=await r.json()}catch(_){d={error:"Respons server tidak valid"}}

    if(!r.ok){
      const serverError=d.error||d.message||`Aktivasi gagal (HTTP ${r.status}).`;
      const [title,text]=explainActivationError(serverError);
      $("licenseMsg").textContent="";
      showActivationAlert(title,text,"error");
      await refreshLicense();
      return;
    }

    await chrome.storage.local.set({
      license:{
        license_key:key,
        expires_at:d.expires_at,
        activated_at:new Date().toISOString()
      }
    });

    $("licenseMsg").textContent=`Lisensi aktif sampai ${formatExpiry(d.expires_at)}.`;
    showActivationAlert(
      "License berhasil diaktifkan",
      `Masa aktif sampai ${formatExpiry(d.expires_at)}. Menu SCRAPE sekarang terbuka.`,
      "success"
    );
    await refreshLicense();
  }catch(e){
    const [title,text]=explainActivationError(e?.message||e);
    $("licenseMsg").textContent="";
    showActivationAlert(title,text,"error");
    lockScrapeMenu();
  }finally{
    btn.disabled=false;
    btn.classList.remove("loading");
    btn.innerHTML="<span>🔐</span> AKTIFKAN LICENSE";
  }
}

async function clearLicense(){
  await chrome.storage.local.remove("license"); $("licenseKey").value="";
  $("licenseMsg").textContent="Data license lokal dihapus. Binding di server TIDAK dihapus; Owner harus Reset Binding jika ingin dipindahkan.";
  await refreshLicense();
}

async function activeTab(){
  const tabs=await chrome.tabs.query({active:true,currentWindow:true});
  return tabs[0];
}
async function pingTab(){
  const tab=await activeTab();
  if(!tab?.id) return false;
  if(!/^https:\/\/cco-agent\.bantusaku\.id\//.test(tab.url||"")) return false;
  try{
    await chrome.tabs.sendMessage(tab.id,{type:"PING"});
    return true;
  }catch(_){return false}
}
const ENGINE_DEFAULTS = Object.freeze({
  concurrency: 8,
  requestConcurrency: 10,
  requestInterval: 0,
  phoneConcurrency: 5,
  paymentConcurrency: 10
});

function scrapeOptions(includePaymentRecap=false){
  const num=(id,fallback)=>{const n=Number($(id)?.value);return Number.isFinite(n)?n:fallback};
  return {
    tenantId:154, pageSize:num("pageSize",100), maxPages:num("maxSize",0), retry:3,
    concurrency:ENGINE_DEFAULTS.concurrency,
    requestConcurrency:ENGINE_DEFAULTS.requestConcurrency,
    requestInterval:ENGINE_DEFAULTS.requestInterval,
    phoneConcurrency:ENGINE_DEFAULTS.phoneConcurrency,
    includePaymentRecap
  };
}

async function startScrape(){
  if(!(await refreshLicense(true))) return;
  const state=await inspectSession();
  if(!state.site){
    showApiModal("Tab belum siap","Buka dan login ke cco-agent.bantusaku.id pada salah satu tab Chrome sebelum menjalankan scraper.","Setelah halaman terbuka dan login, klik Coba Lagi."); return;
  }
  if(!state.content || !state.api){ await checkApiConnection(true); return; }
  try{
    const tab=state.tab;
    await chrome.tabs.sendMessage(tab.id,{type:"START_SCRAPE",options:{
      tenantId:154,pageSize:$("pageSize").value,maxPages:$("maxSize").value,
      retry:3,concurrency:ENGINE_DEFAULTS.concurrency,requestConcurrency:ENGINE_DEFAULTS.requestConcurrency,
       requestInterval:ENGINE_DEFAULTS.requestInterval,phoneConcurrency:ENGINE_DEFAULTS.phoneConcurrency,includePaymentRecap:false
    }});
    runUiActive=true;$("start").disabled=true;$("startPayment").disabled=true;$("stop").disabled=false;$("bar").style.width="0%";
    $("status").textContent="Scrape dimulai...";
  }catch(e){
    $("status").textContent="Session/tab belum siap. Refresh halaman lalu coba lagi.";
    showApiModal("Session/API belum siap","Extension belum menemukan session/API pada tab CCO yang tersimpan. Pastikan salah satu tab CCO tetap terbuka, lalu klik Coba Lagi.","Klik REFRESH HALAMAN dan tunggu sampai halaman selesai dimuat.");
  }
}

async function startPaymentRecap(){
  if(!(await refreshLicense(true))) return;
  const state=await inspectSession();
  if(!state.site){ showApiModal("Tab belum siap","Buka dan login ke cco-agent.bantusaku.id pada salah satu tab Chrome sebelum menjalankan rekap pembayaran.","Setelah halaman terbuka dan login, klik Coba Lagi."); return; }
  if(!state.content || !state.api){ await checkApiConnection(true); return; }
  try{
    const tab=state.tab;
    await chrome.tabs.sendMessage(tab.id,{type:"START_PAYMENT_RECAP",options:{
      tenantId:154,pageSize:$("pageSize").value,maxPages:$("maxSize").value,
      retry:3,concurrency:ENGINE_DEFAULTS.paymentConcurrency,requestConcurrency:ENGINE_DEFAULTS.requestConcurrency,
       requestInterval:ENGINE_DEFAULTS.requestInterval,paymentConcurrency:ENGINE_DEFAULTS.paymentConcurrency
    }});
    runUiActive=true;$("start").disabled=true;$("startPayment").disabled=true;$("stop").disabled=false;$("bar").style.width="0%";
    $("status").textContent="Rekap pembayaran dimulai...";
  }catch(e){
    $("status").textContent="Session/tab belum siap. Refresh halaman lalu coba lagi.";
    showApiModal("Session/API belum siap","Extension belum menemukan session/API pada tab CCO yang tersimpan. Pastikan salah satu tab CCO tetap terbuka, lalu klik Coba Lagi.","Klik REFRESH HALAMAN dan tunggu halaman selesai dimuat.");
  }
}

async function stopScrape(){
  const tab=await findSessionTab();
  if(tab?.id) try{await chrome.tabs.sendMessage(tab.id,{type:"STOP_SCRAPE"})}catch(_){ }
  $("stop").disabled=true;$("status").textContent="Meminta penghentian...";
}

chrome.runtime.onMessage.addListener(msg=>{
  if(msg.type==="SCRAPER_STATUS"){
    if(msg.message) $("status").textContent=msg.message;
  }
  if(msg.type==="SCRAPER_PROGRESS"){
    if(msg.phase==="CASE" || msg.phase==="PAYMENT_CASE") $("status").textContent=`Case page ${msg.page}: ${msg.total} case terkumpul`;
    else if(msg.phase==="PAYMENT") {
      const pct=msg.total?Math.round(msg.index/msg.total*100):0;
      $("bar").style.width=pct+"%";
      $("status").textContent=`Rekap pembayaran ${msg.index}/${msg.total}`;
      $("caseCount").textContent=msg.index||0;
    } else {
      const pct=msg.total?Math.round(msg.index/msg.total*100):0;
      $("bar").style.width=pct+"%";
      $("status").textContent=`Case ${msg.index}/${msg.total} • ${msg.users||0} user • ${msg.contacts||0} contact`;
      $("caseCount").textContent=msg.index||0;$("userCount").textContent=msg.users||0;$("contactCount").textContent=msg.contacts||0;
    }
  }
  if(msg.type==="SCRAPER_DONE"){
    runUiActive=false;$("stop").disabled=true;$("start").disabled=false;$("startPayment").disabled=false;$("bar").style.width="100%";
    $("caseCount").textContent=msg.cases;$("userCount").textContent=msg.users;$("contactCount").textContent=msg.contacts;
    $("status").textContent=`Selesai. File hasil masuk ke folder download "${msg.folder}".`;
  }
  if(msg.type==="SCRAPER_ERROR"){
    runUiActive=false;$("stop").disabled=true;$("start").disabled=false;$("startPayment").disabled=false; refreshLicense(); $("status").textContent="ERROR: "+msg.message;
  }
});

$("menuLicense").onclick=()=>showMenu("license");
$("menuScrape").onclick=async()=>{
  if(await refreshLicense()) showMenu("scrape");
};

(async()=>{
  try{ hardwareId=await getHardwareId(); $("deviceId").textContent=hardwareId; }
  catch(e){ $("deviceId").textContent="DEVICE ID GAGAL DIBUAT"; $("licenseMsg").textContent=e.message; }
  showMenu("license");
  const saved=await getLicense(); $("licenseKey").value=saved.license_key||"";
  if(hardwareId) await refreshLicense();
  if(!$("scrapeView").hidden){
    await checkApiConnection(false);
  }
})();
$("activate").onclick=activate; $("clearLicense").onclick=clearLicense; $("start").onclick=startScrape; $("startPayment").onclick=startPaymentRecap; $("stop").onclick=stopScrape;
$("activationAlertClose")?.addEventListener("click",hideActivationAlert);
$("apiModalClose")?.addEventListener("click",hideApiModal);
$("apiModalRetry")?.addEventListener("click",async()=>{ hideApiModal(); await checkApiConnection(true); });
$("apiModalRefresh")?.addEventListener("click",refreshActivePage);
$("apiModal")?.addEventListener("click",e=>{ if(e.target.classList.contains("api-modal-backdrop")) hideApiModal(); });
chrome.tabs?.onUpdated?.addListener((tabId,changeInfo)=>{
  if(changeInfo.status==="complete" && !$("scrapeView").hidden) setTimeout(()=>checkApiConnection(false),700);
});
setInterval(()=>{ if(!$("scrapeView")?.hidden && !runUiActive) checkApiConnection(false); }, 30000);
// Periodic license validation runs in the background, never inside the scrape request loop.
setInterval(async()=>{
  if(!hardwareId) return;
  const ok=await refreshLicense(true).catch(()=>false);
  if(!ok){
    try{
      runUiActive=false;
      $("start").disabled=false;
      $("startPayment").disabled=false;
      $("stop").click?.();
    }catch(_){}
  }
},2*60*1000);
// NO-REALTIME MESSAGE CLIENT (PERIODIC POLLING)
(function(){
  if(window.__hybridMessageClientStarted) return;
  window.__hybridMessageClientStarted = true;
  const SERVER = (typeof LICENSE_SERVER_URL !== 'undefined' ? LICENSE_SERVER_URL : '').replace(/\/$/,'');
  let pollTimer=null, started=false;
  const seen=new Set();
  let currentStickyId=null;
  let lastMessages=[];

  const css=`
  #hybridMsgOverlay{position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;pointer-events:none;font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
  #hybridMsgCard{pointer-events:auto;width:min(430px,calc(100vw - 32px));border-radius:20px;padding:22px 22px 20px;background:rgba(18,22,32,.97);color:#fff;box-shadow:0 24px 80px rgba(0,0,0,.45);border:1px solid rgba(255,255,255,.12);animation:hybridMsgIn .24s ease-out}
  #hybridMsgCard .hmTop{display:flex;align-items:center;gap:10px;margin-bottom:12px}
  #hybridMsgCard .hmIcon{font-size:24px}.hmTitle{font-weight:800;font-size:17px;flex:1}.hmClose{border:0;background:rgba(255,255,255,.10);color:#fff;border-radius:10px;width:30px;height:30px;cursor:pointer;font-size:17px}.hmClose[hidden]{display:none}
  #hybridMsgCard .hmBody{font-size:14px;line-height:1.6;color:rgba(255,255,255,.88);white-space:pre-wrap;word-break:break-word}.hmSticky{display:inline-flex;margin-top:13px;padding:5px 9px;border-radius:999px;background:rgba(255,193,7,.15);color:#ffd666;font-size:11px;font-weight:800}
  @keyframes hybridMsgIn{from{opacity:0;transform:translateY(10px) scale(.98)}to{opacity:1;transform:none}}
  `;
  function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
  function icon(type){return ({info:'ℹ️',update:'🔄',warning:'⚠️',urgent:'🚨'}[type]||'📢');}
  function ensureUi(){
    if(!document.getElementById('hybridMsgStyle')){const s=document.createElement('style');s.id='hybridMsgStyle';s.textContent=css;document.documentElement.appendChild(s);}
    if(!document.getElementById('hybridMsgOverlay')){const o=document.createElement('div');o.id='hybridMsgOverlay';o.innerHTML='<div id="hybridMsgCard" hidden></div>';document.documentElement.appendChild(o);}
  }
  function hide(){const c=document.getElementById('hybridMsgCard');if(c)c.hidden=true;currentStickyId=null;}
  function show(m){
    if(!m)return;
    ensureUi(); const c=document.getElementById('hybridMsgCard'); if(!c)return;
    const sticky=Number(m.sticky)===1;
    currentStickyId=sticky?Number(m.id):null;
    c.innerHTML=`<div class="hmTop"><span class="hmIcon">${icon(m.type)}</span><span class="hmTitle">${esc(m.title||'Pesan')}</span><button class="hmClose" ${sticky?'hidden':''}>×</button></div><div class="hmBody">${esc(m.body||'')}</div>${sticky?'<div class="hmSticky">📌 PESAN PENTING — TIDAK DAPAT DITUTUP</div>':''}`;
    c.hidden=false;
    if(!sticky){c.querySelector('.hmClose')?.addEventListener('click',hide);setTimeout(()=>{if(currentStickyId===null)c.hidden=true;},8000);}
  }
  function process(messages){
    if(!Array.isArray(messages)) return;
    lastMessages=messages;
    const active=messages.filter(m=>Number(m.active??1)===1);
    if(currentStickyId!==null && !active.some(m=>Number(m.id)===currentStickyId)){hide();}
    const fresh=active.filter(m=>!seen.has(Number(m.id))).sort((a,b)=>Number(b.id)-Number(a.id));
    if(fresh.length){const m=fresh[0];seen.add(Number(m.id));show(m);}
    active.forEach(m=>seen.add(Number(m.id)));
  }
  async function credentials(){
    try{
      const d=await chrome.storage.local.get(['license','device_binding_id','hardware_id']);
      const key=d?.license?.license_key||''; const hw=window.hardwareId||d?.device_binding_id||d?.hardware_id||'';
      if(!key||!hw)return null; return {key,hw};
    }catch(_){return null;}
  }
  async function pollOnce(){
    const c=await credentials(); if(!c)return;
    try{const r=await fetch(SERVER+'/client/messages',{method:'POST',headers:{'content-type':'application/json'},cache:'no-store',body:JSON.stringify({license_key:c.key,hardware_id:c.hw,tool:chrome.runtime.getManifest().name,version:chrome.runtime.getManifest().version})});if(!r.ok)return;const d=await r.json();if(d?.valid)process(d.messages||[]);}catch(_){ }
  }
  function stopPoll(){if(pollTimer){clearInterval(pollTimer);pollTimer=null;}}
  function startPoll(){if(pollTimer)return;pollOnce();pollTimer=setInterval(pollOnce,60000);}
  async function start(){if(started)return;started=true;ensureUi();startPoll();}
  window.startHybridMessageCenter=start;
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(start,800)); else setTimeout(start,800);
})();
