window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  const d = event.data;
  if (!d || d.source !== "BANTUSAKU_AUTH_BRIDGE" || d.type !== "AUTH") return;

  // This file is normally an MV3 isolated-world content script. Some Chrome
  // contexts can execute the bridge without exposing chrome.runtime; never
  // let that optional auth bridge break the CCO page or SMS flow.
  try {
    if (typeof chrome === "undefined" || !chrome.runtime || typeof chrome.runtime.sendMessage !== "function") return;
    const result = chrome.runtime.sendMessage({
      type: "capturePageAuth",
      headers: d.headers || {},
      url: d.url || ""
    });
    if (result && typeof result.catch === "function") result.catch(() => {});
  } catch (_) {}
});
